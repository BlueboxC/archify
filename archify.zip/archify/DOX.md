# DOX.md — Archify Skill

## Purpose

Own the zero-dependency installed CLI, renderers, checker, Viewer, authoring contracts and regression tests.

## Ownership

This boundary owns `bin/`, `renderers/`, `scripts/`, `delta/`, `assets/`, `schemas/`, `references/`, bundled examples and `test/`.

## Local Contracts

- Preserve authored topology and explicit routing. Coincident relationships may be intentional; use an actionable showcase warning instead of automatically rerouting them.
- Boundary membership is authored data. Older HTML without membership metadata remains readable and explicitly unjudged by that rule; never infer membership from labels.
- Checker transport failure is not an artifact verdict. Preserve previous delivered output when verification cannot complete.
- Preview retains the last verified artifact independently of checking/failure status; same-revision state updates preserve the loaded document.
- Keep fonts embedded and preserve THIRD_PARTY_NOTICES.md and asset licenses. No new runtime dependencies or automatic installation/update side effects.

## Work Guidance

- Reuse the shared geometry, diagnostic and tracked-package interfaces. Keep upstream-derived tests and attribution with adaptations.
- Test through CLI or emitted artifacts, including compatibility and failure paths; a version string does not establish installed source equivalence.

## Verification

- `npm test`; focused boundary-membership, coincident-routes, checker-buffer and preview regressions.
- Regenerate affected examples/gallery and compare source, staged package and installed bytes.

## Child DOX Index

- None; the Skill's runtime contracts are owned here.
