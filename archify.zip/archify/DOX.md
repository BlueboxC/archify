# DOX.md — Archify Skill

## Purpose

Own the zero-dependency installed CLI, renderers, checker, Viewer and authoring contracts, with bundled Story and Code Analysis boundaries.

## Ownership

This boundary owns `bin/`, `renderers/`, `scripts/`, `delta/`, `assets/`, `schemas/`, `references/`, bundled examples. `story/` owns native walkthrough attachment, choreography and presentation exports. `modules/code-analysis/` owns its separate package, static-analysis pipeline and local workbench. `explainer/` owns structured explanatory documents and chart compilation. Root `test/` owns tests and root `viewer/` owns Viewer sources.

## Local Contracts

- Preserve authored topology and explicit routing. Coincident relationships may be intentional; use an actionable showcase warning instead of automatically rerouting them.
- Boundary membership is authored data. Older HTML without membership metadata remains readable and explicitly unjudged by that rule; never infer membership from labels.
- Layout JSON mode drains stdout without creating or replacing HTML. SVG root discovery and geometry readers share a single-pass tokenizer with attribute-aware tag endings and self-closing flags. Preserve comment/CDATA context, script/style text exclusion, ASCII tag delimiters and the full root after nested SVG elements; this is a scoped artifact scanner rather than a general HTML validator.
- Checker transport failure is not an artifact verdict. Preserve previous delivered output when verification cannot complete.
- Explainer checker receipts fully drain piped stdout before exit, preserving a single JSON receipt and verdict exit code.
- Class method styling preserves authored parameter delimiters and whitespace. Timeline title wrapping keeps complete grapheme clusters and existing CJK punctuation grouping.
- Repository evidence accepts only the supplied commit object identity; refuse tag/tree/blob IDs without silently peeling them. GitHub/GitLab Markdown line citations use plain source; path-only citations remain unchanged.
- Preview retains the last verified artifact independently of checking/failure status; same-revision state updates preserve the loaded document.
- Migration validates complete source/final semantic contracts; group repair spans preserve exact membership and each node's effective group identity under canonical ordering, including overlapping groups with equal labels. Self-calls retain ownership, notes and identity. Raster pins undergo container checks even with matching digests.
- ERD renderer-added trunk bridges avoid unrelated routes and prior bridges using rendered stroke widths; preserve authored routes, ports and cardinality.
- Timeline cards, accessible labels and fallback ticks preserve nonzero milliseconds. Waterfall labels retain time resolution and visible endpoints without changing span/tick geometry.
- Timeline ticks follow display-zone offset transitions without changing elapsed event geometry. Browser discovery keeps explicit overrides authoritative and prefers Chrome/Chromium before Edge.
- Redirected finalize evidence retains historical full/browser receipts; the adjacent guarded summary tracks the latest attempt, including failures. `--out-dir` does not relocate the HTML or delivery provenance.
- Delivery and finalize protect declared local Explainer chart and native-diagram inputs from artifact, provenance, journal, lock and receipt aliases before publication. Discover paths before resource preparation so invalid-data redelivery also preserves inputs; uninspectable drafts withhold failure-sidecar writes.
- Note-overlap repairs describe one jointly verified translation of the affected message suffix; reject plans that create canvas, note, segment, or legend failures. Preserve authored messages and ordering.
- Authoring and delivery references use short topic indexes; keep legacy heading links reachable and current exit-code semantics documented.
- Repository evidence preserves the exact Git top-level filesystem spelling; normalize remote origins separately before identity comparison and credential redaction.
- Keep fonts embedded and preserve THIRD_PARTY_NOTICES.md and asset licenses, including the Apache-2.0 license/notice for adapted PR1106/1109/1117 portions beside the retained MIT base. No new runtime dependencies or automatic installation/update side effects.

- Timeline dates retain years across year boundaries; subsecond omitted intervals state milliseconds. Waterfall timing agreement accounts for binary64 magnitude, and the incomplete legend describes only open bars. Neutral relationship text uses readable theme-specific ink without recoloring connectors or semantic variants. Exports use the authored heading and NFC Unicode letters/numbers with attached marks to retain localized titles; detached marks are removed and names without a letter or number use the existing fallback. Older/custom pages without a heading retain their complete document title instead of guessing at suffix words.

- Print CSS clears hidden navigation clearance independently of JavaScript; screen/mobile dock behavior stays measured.

- Tree label/sublabel, Timeline title and Sequence note wrapping keep closing CJK punctuation, iteration marks and ellipses with the preceding piece, and opening brackets with the following piece, including authored whitespace after the bracket. Timeline retains complete grapheme clusters. Keep width measurement, fonts and non-CJK wrapping; this is a scoped punctuation rule, not complete Unicode line breaking.

- Automatic workflow port probing skips occupied intervals and repeated floating-point coordinates on the bounded spacing grid. Preserve stroke-aware clearance, later usable ports, finite authored dimensions and ordinary routing; stop when no distinct bounded candidate remains.
- Failed schema-v2 relative drop forks may retry opposite source-port order at up to four stably selected forks per compile invocation. Speculative candidates disable repair-hint discovery while retaining full validation. Accept only a fully validated compile; keep successful scenes, authored topology/sides and absolute geometry. Outer layout feedback retains its independent bounds.
- Indeterminate sidecar namespaces produce structured provenance/evidence failures without an alternative write path or treating unknown provenance as verified.

- Windows native realpath EPERM may fall back to Node JS realpath only for an existing non-link directory ancestor. Require matching stable filesystem identity after resolution; leaves, roots, other errors and unresolved identities remain strict. Preserve destination/containment checks; injected tests do not establish native Windows sandbox acceptance.
- Owned temporary-directory ancestor comparisons keep sameEntry first. On Windows EPERM only, a fallback comparison requires non-link directory identities with nonzero inode and stable dev/inode/birthtime before and after inspection. Preserve the full bound ancestor chain and replacement refusal during creation and cleanup.

- Crossing inspection allows 50,000 eligible relationship pairs and 3,000,000 segment-pair checks by default. Normalize visible-route segments before selecting eligible pairs; pure quadratic routes with no inspected segments consume no pair budget. Exhaustion fails explicitly as incomplete in every quality profile; never report partial inspection as a pass. Public check/deliver/finalize diagnostics retain the matching per-invocation recovery knob. Positive safe-integer environment overrides can qualify a known-large artifact; these bounds do not limit all checker work or guarantee a wall-clock deadline.

- Workflow compilation caches lane-prefix geometry and first-occurrence node indexes per invocation. Preserve authored lane positions, main-path/off-path animation order and complete emitted results.

- Dataflow validation uses collection indexes directly. Unknown-endpoint diagnostics and fixes point to each occurrence, including repeated in-memory references; ordinary JSON inputs retain their existing results.

## Work Guidance

- Reuse the shared geometry, diagnostic and tracked-package interfaces. Keep upstream-derived tests and attribution with adaptations.
- Test through CLI or emitted artifacts, including compatibility and failure paths; a version string does not establish installed source equivalence.

## Verification

- Root `npm run test:full`; focused boundary-membership, coincident-routes, checker-buffer and preview regressions.
- Regenerate affected examples/gallery and compare source, staged package and installed bytes.

## Child DOX Index

- [story/DOX.md](story/DOX.md) — walkthrough attachment, choreography, source excerpts and recoverable media outputs.
- [modules/code-analysis/DOX.md](modules/code-analysis/DOX.md) — separate analysis package, captured facts, findings, task evidence and loopback workbench.
- [explainer/DOX.md](explainer/DOX.md) — structured document rendering and data-chart fidelity.

- [references/DOX.md](references/DOX.md) — on-demand guidance, routing indexes and compatibility links. Runtime contracts remain owned here.
